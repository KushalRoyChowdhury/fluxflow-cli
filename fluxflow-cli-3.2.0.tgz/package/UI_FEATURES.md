# 🎮 User Interface & Interaction Features

Flux Flow is designed to be a high-performance terminal application. Beyond basic chat, it includes a variety of advanced UI features and human-in-the-loop controls to keep you in command of the agent.

## ⌨️ Command System

You can control the application using `/` commands directly in the chat input:

- **/mode [flux|flow]**: Quickly switch between **Flux** (Dev) and **Flow** (Chat) modes.
- **/thinking [fast|low|medium|high|max]**: Adjust reasoning depth.
- **/model [name]**: Choose which AI model to use for the main interaction.
- **/key**: Open the API Key management view to update or remove your credentials.
- **/settings**: Access the system configuration menu.
- **/profile**: Update your name, nickname, and custom instructions.
- **/update**: Update Flux Flow to the latest version.
- **/memory**: View and manage the persistent memories extracted by the Janitor.
- **/resume <chat-id>**: Switch back to a previous conversation.
- **/changelog**: Open the project's changelog in your default browser.
- **/help**: List all available commands.

## 📁 External Data Sanctuary (Redirection)

Flux Flow allows you to "Anchor" your data outside of the default user directory. This is perfect for users who want to keep their logs, chat history, and encrypted memories on an external drive, a VeraCrypt volume, or a specific project folder.

- **How to Enable**: Open `/settings` and toggle **Use External Data**.
- **Portability**: Once set, the application will synchronously "pivot" all data operations to your specified `externalDataPath` upon startup.
- **Privacy**: Keeps sensitive data off your primary system drive.

## 🧠 Thinking Levels & Visualization

Flux Flow separates the model's "internal monologue" (reasoning) from its final response using `<think>` tags.

- **Thinking Levels**: Depending on the mode, you can choose from **Fast**, **Low**, **Medium**, **High**, or **xHigh**. Higher levels allow the agent more "space" to reason through complex architecture or debugging problems.

## ⚡ Interactive Sub-Terminal

Flux Flow features a high-fidelity, interactive sub-terminal that allows you to engage with commands spawned by the agent in real-time.

- **Live Interaction**: When an agent executes a command (like `npm init`, `git commit`, or a custom script), the terminal output appears in a dedicated box.
- **Focus Toggling (`TAB`)**: While a terminal is live, you can press **`TAB`** to shift your keyboard focus from the chat prompt directly into the terminal.
- **Visual Feedback**:
  - **Yellow Glow**: When the terminal is focused, its border changes to a "Double Yellow" style to indicate it is capturing input.
  - **Status Indicator**: The footer will change from `● LIVE` to `▶ TERMINAL FOCUSED`.
- **Cross-Platform Compatibility**: The input bridge automatically detects your OS and sends the correct line endings (`\r\n` for Windows, `\n` for Unix), ensuring that interactive prompts like `y/n` work seamlessly across environments.
- **Input Mirroring**: Your keystrokes are mirrored in the terminal box in real-time, providing an IDE-grade responsive feel.

> [!TIP]
> Use the Interactive Sub-Terminal to handle authentication prompts, confirmation dialogs, or to manually steering a long-running process without leaving the Flux Flow interface.

## 🛡️ Human-in-the-Loop (HITL) Verification

Security and safety are paramount when an AI has access to your file system and terminal. Flux Flow implements several layers of verification:

### Tool Approval
By default, the agent **cannot** execute dangerous actions without your consent.
- **Terminal Approval**: If the agent attempts to run a shell command (`exec_command`), a dedicated approval screen appears showing the exact command. You can **Allow** or **Deny** the execution.
- **File Approval**: Similar to terminal commands, writing or updating files requires manual approval unless configured otherwise.
- **Safe Commands**: Basic read-only commands (like `ls`, `git status`, `pwd`) are automatically allowed to minimize friction.

### Auto-Execution (Advanced)
For power users, **YOLO Mode** can be enabled in `/settings`.
- **⚠️ Warning**: This allows the agent to run any tool and execute any command autonomously.
- **External Access**: You can also toggle whether the agent is allowed to access files outside of its current working directory.
- **Manual Commad Control**: Specify which commands you want the agent to auto-execute, manually approve or auto-deny.
- **Network Sandboxing**: Turn off network access in integrated terminal.

## 🔄 Steering & Resolution

### Real-time Steering
If you realize the agent is going down the wrong path *while* it is in an agentic loop, you can provide "Steering Hints." The system will inject your feedback into the next loop to course-correct the agent.

### Resolution Modal
If the agent finishes its task just as you send a steering hint, a **Resolution Modal** appears. It asks if you want to:
- **Send Anyway**: Start a new loop with your feedback.
- **Edit Prompt**: Refine your feedback before sending.

## 📊 Status Bar & Feedback
The bottom of the screen features a dynamic status bar showing:
- **Active Mode** (Flux/Flow)
- **Thinking Level**
- **Token Usage**: Real-time tracking of tokens used in the current session.
- **Agentic Loops**: Counters showing how many times the agent has "looped" to solve the current task.
- **API Status**: Visual feedback when the model is thinking or executing a tool.

## 🚑 System Integrity & Self-Healing

Flux Flow is a "Self-Healing" agent. It actively monitors its own environment to ensure all complex dependencies (like the Chromium engine for PDF generation) are ready for action.

- **Startup Integrity Check**: On launch, Flux performs a "Heartbeat Check" on its internal engines.
- **Automatic Recovery**: If a dependency is missing, you will see a `🔧 [SYSTEM] Initializing...` message. Flux will autonomously download and configure the required binaries using `pnpm` or `npx` fallbacks, keeping you informed every step of the way.
- **Silent Maintenance**: Once the engine is ready, you'll receive a `✅ [SYSTEM] All dependencies installed successfully.` confirmation.